package se.unlogic.standardutils.callback;


public interface Callback<T> {

	public void callback(T type);
}
