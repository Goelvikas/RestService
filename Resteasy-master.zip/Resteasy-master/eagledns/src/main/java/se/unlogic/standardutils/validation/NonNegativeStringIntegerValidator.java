package se.unlogic.standardutils.validation;


public class NonNegativeStringIntegerValidator extends StringIntegerValidator {

	public NonNegativeStringIntegerValidator() {

		super(0, null);
	}	
}
