package org.jboss.resteasy.resteasy1630;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/two")
public class TestApplicationPath extends Application
{
}
